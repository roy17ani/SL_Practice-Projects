import java.io.*;
public class FileHandlingExample {

	public static void main(String[] args) {
        // Get file name from user
        String fileName = getUserInput("Enter the file name (including extension):");
        String filePath = fileName; // You can specify the directory path if needed
        
        // Write to file
        String initialContent = getUserInput("Enter initial content to write to the file:");
        writeToFile(filePath, initialContent);
        
        // Read from file
        String content = readFromFile(filePath);
        System.out.println("Content of the file:");
        System.out.println(content);
        
        // Append to file
        String appendContent = getUserInput("Enter content to append to the file:");
        appendToFile(filePath, appendContent);
        
        // Read again after appending
        content = readFromFile(filePath);
        System.out.println("Content of the file after appending:");
        System.out.println(content);
    }

    // Method to get user input
    public static String getUserInput(String prompt) {
        System.out.println(prompt);
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            return reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Method to write content to a file
    public static void writeToFile(String filePath, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(content);
            System.out.println("Content written to file successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to read content from a file
    public static String readFromFile(String filePath) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content.toString();
    }

    // Method to append content to a file
    public static void appendToFile(String filePath, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            writer.write("\n" + content); // Append with a new line
            System.out.println("Content appended to file successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}