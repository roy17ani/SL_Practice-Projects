import java.util.Scanner;
public class LongestIncreasingSubsequence {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input: Read the size of the array
        System.out.print("Enter the number of elements: ");
        int n = scanner.nextInt();

        // Input: Read the array elements
        int[] arr = new int[n];
        System.out.println("Enter the array elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }

        // Compute the LIS length
        int lisLength = findLISLength(arr, n);

        System.out.println("Length of the longest increasing subsequence is: " + lisLength);
    }

    // Function to find the LIS length
    private static int findLISLength(int[] arr, int n) {
        int[] lis = new int[n];
        for (int i = 0; i < n; i++) {
            lis[i] = 1; // Initialize LIS length for each element as 1
            for (int j = 0; j < i; j++) {
                if (arr[i] > arr[j]) {
                    lis[i] = Math.max(lis[i], lis[j] + 1);
                }
            }
        }

        // Find the maximum LIS length
        int maxLIS = 0;
        for (int i = 0; i < n; i++) {
            maxLIS = Math.max(maxLIS, lis[i]);
        }

        return maxLIS;
    }
}