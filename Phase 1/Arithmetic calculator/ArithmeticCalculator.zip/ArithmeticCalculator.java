import java.util.Scanner;
public class ArithmeticCalculator {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // User Input Loop
        while (true) {
            System.out.println("\nArithmetic Calculator Menu:");
            System.out.println("1. Addition");
            System.out.println("2. Subtraction");
            System.out.println("3. Multiplication");
            System.out.println("4. Division");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            double result = 0.0;

            switch (choice) {
                case 1:
                    result = performAddition(scanner);
                    break;
                case 2:
                    result = performSubtraction(scanner);
                    break;
                case 3:
                    result = performMultiplication(scanner);
                    break;
                case 4:
                    result = performDivision(scanner);
                    break;
                case 5:
                    System.out.println("Exiting program.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid Choice!");
                    continue;
            }

            System.out.println("Result: " + result);

            System.out.print("Do you want to perform another operation? (yes/no): ");
            String continueChoice = scanner.next();

            if (!continueChoice.equalsIgnoreCase("yes")) {
                System.out.println("Exiting program.");
                scanner.close();
                return;
            }
        }
    }

    public static double performAddition(Scanner scanner) {
        System.out.print("Enter first number: ");
        double num1 = scanner.nextDouble();
        System.out.print("Enter second number: ");
        double num2 = scanner.nextDouble();
        return num1 + num2;
    }

    public static double performSubtraction(Scanner scanner) {
        System.out.print("Enter first number: ");
        double num1 = scanner.nextDouble();
        System.out.print("Enter second number: ");
        double num2 = scanner.nextDouble();
        return num1 - num2;
    }

    public static double performMultiplication(Scanner scanner) {
        System.out.print("Enter first number: ");
        double num1 = scanner.nextDouble();
        System.out.print("Enter second number: ");
        double num2 = scanner.nextDouble();
        return num1 * num2;
    }

    public static double performDivision(Scanner scanner) {
        System.out.print("Enter numerator: ");
        double numerator = scanner.nextDouble();
        System.out.print("Enter denominator: ");
        double denominator = scanner.nextDouble();
        if (denominator == 0) {
            System.out.println("Error: Division by zero");
            return Double.NaN; // Return NaN (Not-a-Number) for division by zero
        }
        return numerator / denominator;
    }
}
