import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class EmailValidator {

	public static void main(String[] args) {
        // Predefined email IDs for 10 people
        String[] emailArray = {
        		"john@gmail.com", 
        	    "jane@yahoo.com", 
        	    "smith@outlook.com", 
        	    "doe@hotmail.com",
        	    "alice@icloud.com",
        	    "bob@aol.com",
        	    "emma@protonmail.com",
        	    "michael@zoho.com",
        	    "sara@inbox.lv",
        	    "peter@mail.com"
        };

        // Prompt the user to input an email ID
        System.out.print("Enter an email ID to search: ");
        Scanner scanner = new Scanner(System.in);
        String userInput = scanner.nextLine();

        // Validate the format of the entered email ID
        if (isValidEmail(userInput)) {
            // Perform search
            boolean found = false;
            for (String email : emailArray) {
                if (email.equals(userInput)) {
                    found = true;
                    break;
                }
            }

            // Display search result
            if (found) {
                System.out.println("Valid email ID and email ID found in the array.");
            } else {
                System.out.println("Valid email ID but email ID not found in the array.");
            }
        } else {
            System.out.println("Invalid email ID.");
        }

        scanner.close();
    }

    // Method to validate the format of an email ID
    private static boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }
}